/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000002715821447_0245188164_init();
    work_m_00000000001383148761_2601983858_init();
    work_m_00000000004057293403_0590668275_init();
    work_m_00000000000243787379_3049211330_init();
    work_m_00000000002188802922_0614071818_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002188802922_0614071818");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
